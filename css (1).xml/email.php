<?php
$emailku = 'YourEmailHere'; // Join My Telegram Channel For More Scripts @MyBadCodes
?>